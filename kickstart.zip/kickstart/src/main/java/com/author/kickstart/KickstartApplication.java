package com.author.kickstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KickstartApplication {

	public static void main(String[] args) {
		SpringApplication.run(KickstartApplication.class, args);
	}

}
